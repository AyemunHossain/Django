from django.apps import AppConfig

class BlogpostsConfig(AppConfig):
    name = 'blogPosts'