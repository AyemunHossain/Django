 .................................................................................................................................

 DJANGO BENINNER PROJECT - 1 >>>Tutorial Website
 .................................................................................................................................

 >This is a tutorial website source code. This will be helpful for those who are trying to make any tutorial web site.
 >So this template will show you a bunch of tutorials in Category wise and series wise.
 >Like you have some category and your category will have some series and series may have several tutorials.
 >So you can add tutorials and category/series by login as admin. And your user can create and login/logout form their account.
 >Only the admin can add,delete or change tutorials and category/series or user information. 
 >And this site is safe from CSRF/XSRF attacks and many more.

Font-end:
	I have used Materialize.css ....to downloadv : https://materializecss.com/getting-started.html
	I have used a text editor called tinymce ... to download: python3 -m pip install django-tinymce4-lite.


Backend-end(Django):
	1.Model Design
	2.Custom Form Design
	3.Admin site register
	4.Building Custom views
	5.Dynamic+Static Url loading 
	6.Dynamic page redirecting
	7.Registration+Login Form with profervalidation 
	8.CSRF Attack prevention factor added
	9.Custom User Model and user profile
	
	